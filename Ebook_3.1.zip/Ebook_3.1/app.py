from flask import Flask, flash, render_template, request, redirect, url_for, session
from flask_mysqldb import MySQL
from flask_paginate import Pagination
import MySQLdb.cursors
import re
import random
import datetime

app = Flask(__name__, static_folder='static')

app.secret_key = 'your secret key'

app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = '1234'
app.config['MYSQL_DB'] = 'ebook'

mysql = MySQL(app)

@app.route("/main")
def main():
	if 'loggedin' in session:
		return render_template("main.html")

class home():
    @app.route('/')
    def home():
        cursor = mysql.connection.cursor()
        # 발행일을 기준으로 최근 10개의 책 query에 저장
        query = "SELECT * FROM book ORDER BY publishdate DESC LIMIT 10"
        cursor.execute(query)
        latest_books = cursor.fetchall()
        cursor.close()
        # 랜덤으로 3개의 책 new_books에 저장
        new_books = random.sample(latest_books, 3)
        cursor = mysql.connection.cursor()
        query = "SELECT * FROM book"
        cursor.execute(query)
        results = cursor.fetchall()
        cursor.close()
        recommended_books = random.sample(results, 3)
        return render_template('main.html', 
                            new_books=new_books,
                            recommended_book_1=recommended_books[0], 
                            recommended_book_2=recommended_books[1], 
                            recommended_book_3=recommended_books[2])

@app.route('/search')
def search():
    keyword = request.args.get('keyword', '')
    if keyword:
        cursor = mysql.connection.cursor()
        query = f"SELECT * FROM book WHERE name LIKE '%{keyword}%' ORDER BY name"
        cursor.execute(query)
        results = cursor.fetchall()
        cursor.close()
    else:
        results = []
    return render_template('booklist.html', results=results)

@app.route('/books/genre/<string:genre>')
def book_by_genre(genre):
    page = int(request.args.get('page', 1))
    per_page = 10
    offset = (page - 1) * per_page
    cursor = mysql.connection.cursor()
    if genre == '전체':
        count_query = "SELECT COUNT(*) FROM book"
        query = "SELECT * FROM book LIMIT %s OFFSET %s"
        cursor.execute(count_query)
        total = cursor.fetchone()[0]
        cursor.execute(query, (per_page, offset,))
    else:
        count_query = "SELECT COUNT(*) FROM book WHERE TRIM(genre) = %s"
        query = "SELECT * FROM book WHERE TRIM(genre) = %s LIMIT %s OFFSET %s"
        cursor.execute(count_query, (genre,))
        total = cursor.fetchone()[0]
        cursor.execute(query, (genre, per_page, offset,))
    results = cursor.fetchall()
    cursor.close()
    pagination = Pagination(page=page, per_page=per_page, total=total, css_framework='bootstrap4')

    return render_template('books.html', results=results, pagination=pagination, genre=genre)



@app.route('/books/<int:number>')
def book_detail(number):
    cursor = mysql.connection.cursor()
    query = "SELECT * FROM book WHERE number = %s"
    cursor.execute(query, (number,))
    result = cursor.fetchone()
    cursor.close()
    return render_template('book.html', result=result)

@app.route('/recommended_book')
def recommended_book():
    cursor = mysql.connection.cursor()
    cursor.execute("SELECT * FROM book ORDER BY RAND() LIMIT 1")
    recommended_book = cursor.fetchone()
    cursor.close()
    return render_template('recommended_book.html', recommended_book=recommended_book)

@app.route('/login', methods=['GET', 'POST'])
def login():
    msg = ''
    if request.method == 'POST' and 'account' in request.form and 'password' in request.form:
        account = request.form['account']
        password = request.form['password']
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute(
            'SELECT * FROM user WHERE account = % s AND password = % s', 
            (account, password)
        )
        user = cursor.fetchone()
        if user:
            session['loggedin'] = True
            session['account'] = user['account']
            session['password'] = user['password']
            msg = 'Logged in successfully!'
            return redirect(url_for('home'))
        else:
            msg = 'Incorrect username/password!'
    return render_template('login.html', msg=msg)


@app.route('/logout')
def logout():
    session.pop('cart', None)
    session.pop('loggedin', None)
    session.pop('account', None)
    session.pop('password', None)
    return redirect(url_for('home'))

@app.route('/signup', methods=['GET', 'POST'])
def signup():
	msg = ''
	if request.method == 'POST' \
	and 'account' in request.form \
	and 'password' in request.form \
    and 'username' in request.form \
    and 'email' in request.form \
	and 'gender' in request.form \
	and 'birth' in request.form \
	and 'phonenumber' in request.form:
		account = request.form['account']
		password = request.form['password']
		username = request.form['username']
		email = request.form['email']
		gender = request.form['gender']
		birth = request.form['birth']
		phonenumber = request.form['phonenumber']
		cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
		cursor.execute(
			'SELECT * FROM user WHERE account = % s', (account, ))
		user = cursor.fetchone()
		if user:
			msg = '이미 존재하는 계정입니다 !'
		elif not re.match(r'[^@]+@[^@]+\.[^@]+', email):
			msg = '이메일 형식에 맞지 않습니다 !'
		elif not re.match(r'^[a-zA-Z0-9가-힣]+$', username):
			msg = '이름은 영어와 숫자, 한글로만 구성되어야 한다 !'
		else:
			cursor.execute('INSERT INTO user VALUES \
		        (% s, % s, % s, % s, % s, % s, % s)', 
               (account, password, username, email, gender, birth, phonenumber))
			mysql.connection.commit()
			msg = '가입을 환영합니다 !'
			return redirect('/login')
	elif request.method == 'POST':
		msg = 'Please fill out the form !'
	return render_template('signup.html', msg=msg)

@app.route('/password-retrieval', methods=['GET', 'POST'])
def password_retrieval():
    msg = ''
    if request.method == 'POST' and 'account' in request.form:
        account = request.form['account']
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute(
            'SELECT * FROM user WHERE account = % s', (account, ))
        user = cursor.fetchone()
        if user:
            # 임시 비밀번호 생성 및 업데이트
            import random
            import string
            temp_password = ''.join(random.choices(string.ascii_letters + string.digits, k=8))
            cursor.execute(
                'UPDATE user SET password = %s WHERE account = %s',
                (temp_password, account))
            mysql.connection.commit()
            
            # 결과를 바로 출력
            msg = f"임시 비밀번호는 {temp_password}입니다."
        else:
            msg = '존재하지 않는 계정입니다.'
    elif request.method == 'POST':
        msg = '계정을 입력해주세요.'
    return render_template('password-retrieval.html', msg=msg)

@app.route("/update", methods=['GET', 'POST'])
def update():
    msg = ''
    if 'loggedin' in session:
        if request.method == 'POST':
            if '' in [request.form[field] for field in ['password', 'username', 'email', 'gender', 'birth', 'phonenumber']]:
                msg = 'Please fill out the form !'
            else:
                account = session['account']
                password = request.form['password']
                username = request.form['username']
                email = request.form['email']
                gender = request.form['gender']
                birth = request.form['birth']
                phonenumber = request.form['phonenumber']
                cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
                cursor.execute(
                    'UPDATE user SET password=%s, username=%s, email=%s, gender=%s, birth=%s, phonenumber=%s WHERE account=%s', 
                    (password, username, email, gender, birth, phonenumber, account))
                mysql.connection.commit()
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM user WHERE account = % s', (session['account'], ))
        user = cursor.fetchone()
        return render_template('mypage.html', user=user)
    else:
        return redirect(url_for('login'))

@app.route("/update_result")
def update_result():
    msg = request.args.get('msg')
    return render_template("update_result.html", msg=msg)

@app.route('/mypage')
def mypage():
    if 'loggedin' not in session:
        return redirect(url_for('login', next='/mypage'))

    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute('SELECT * FROM user WHERE account = %s', (session['account'],))
    user = cursor.fetchone()

    cursor.execute('''
        SELECT purchase.purchase_date, purchase.price 
        FROM purchase 
        JOIN user ON user.account=purchase.account 
        WHERE purchase.account=%s
    ''', (user['account'],))
    purchases = cursor.fetchall()

    books = []
    for purchase in purchases:
        cursor.execute('''
            SELECT name 
            FROM book 
            WHERE number = (
                SELECT number 
                FROM purchase 
                WHERE account=%s AND purchase_date=%s AND price=%s
            )
        ''', (user['account'], purchase['purchase_date'], purchase['price']))
        book = cursor.fetchone()
        books.append((book['name'], purchase['purchase_date'], purchase['price']))

    return render_template('mypage.html', user=user, books=books)

# @app.route('/mypage')
# def mypage():
#     if 'loggedin' not in session:
#         return redirect(url_for('login', next='/mypage'))
#     cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
#     cursor.execute('SELECT * FROM user WHERE account = % s', (session['account'], ))
#     user = cursor.fetchone()
#     return render_template('mypage.html', user=user)

@app.route('/add_to_cart', methods=['POST'])
def add_to_cart():
    if 'loggedin' not in session:
        return redirect(url_for('login'))
    if 'cart' not in session:
        session['cart'] = {}
    book_number = request.form['number']
    cursor = mysql.connection.cursor()
    cursor.execute('SELECT * FROM book WHERE number = %s', (book_number,))
    book = cursor.fetchone()
    if book:
        session['cart'][book_number] = {'title': book[1], 'price': book[5]}
        flash('Book has been added to the cart.', 'success')
    return redirect(url_for('cart'))


@app.route('/cart')
def cart():
    if 'loggedin' not in session:
        return redirect(url_for('login'))
    if 'cart' not in session:
        session['cart'] = {}
    cart_items = []
    total_price = 0
    for book_number, item in session['cart'].items():
        cursor = mysql.connection.cursor()
        cursor.execute('SELECT * FROM book WHERE number = %s', (book_number,))
        book = cursor.fetchone()
        if book:
            item_price = book[5]
            cart_items.append({'number': book_number, 'title': book[1], 'item_price': item_price})
            total_price += int(item_price)
        else:
            del session['cart'][book_number]
            error_msg = f"Book with number {book_number} is no longer available."
            return render_template('error.html', error_msg=error_msg)
    return render_template('cart.html', cart_items=cart_items, total_price=total_price)

@app.route('/remove_from_cart/<book_number>', methods=['GET', 'POST'])
def remove_from_cart(book_number):
    if 'loggedin' not in session:
        return redirect(url_for('login'))
    if 'cart' in session and book_number in session['cart']:
        del session['cart'][book_number]
        flash('Book has been removed from the cart.', 'success')
    return redirect(url_for('cart'))

@app.route('/checkout', methods=['GET', 'POST'])
def checkout():
    if 'loggedin' not in session:
        return redirect(url_for('login'))
    account = session['account']
    cart_items = session['cart']
    purchase_date = datetime.date.today()
    cursor = mysql.connection.cursor()
    purchase_id = cursor.lastrowid
    total_price = 0
    purchases = []
    for item in cart_items:
        number = item
        cursor.execute("SELECT name, price FROM book WHERE number = %s", (number,))
        result = cursor.fetchone()
        name, price = result[0], result[1]
        query = "INSERT INTO purchase (purchase_id, account, number, purchase_date, price) VALUES (%s, %s, %s, %s, %s)"
        cursor.execute(query, (purchase_id, account, number, purchase_date, price,))
        mysql.connection.commit()
        total_price += price
        purchases.append({'name': name, 'price': price})
    cursor.close()
    session['cart'] = {}
    session['total_price'] = total_price
    return render_template('checkout.html', cart_items=purchases, total_price=total_price)



if __name__ == '__main__':
    app.run(debug=True)
