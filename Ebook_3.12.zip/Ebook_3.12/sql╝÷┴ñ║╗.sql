CREATE TABLE `user`(
    `account` char(30) NOT NULL,
    `username` VARCHAR(255) NOT NULL,
    `password` VARCHAR(50) NOT NULL,
    `email` VARCHAR(100) NOT NULL,
    `gender` VARCHAR(10) NOT NULL,
    `birth` DATE NOT NULL,
    `phonenumber` VARCHAR(30) NOT NULL
);
ALTER TABLE
    `user` ADD PRIMARY KEY(`account`);

CREATE TABLE `book`(
    `number` INT NOT NULL,
    `name` VARCHAR(100) NOT NULL,
    `author` VARCHAR(50) NOT NULL,
    `publisher` VARCHAR(50) NOT NULL,
    `publishdate` DATE NOT NULL,
    `price` INT NOT NULL,
    `description` TEXT NOT NULL,
    `image` VARCHAR(255) NOT NULL,
    `genre` varCHAR(255) NOT NULL
);
ALTER TABLE
    `book` ADD PRIMARY KEY(`number`);

CREATE TABLE purchase (
    purchase_id INT NOT NULL AUTO_INCREMENT,
    account char(30) NOT NULL,
    number int NOT NULL,
    purchase_date DATE NOT NULL,
    price INT NOT NULL,
    PRIMARY KEY (purchase_id),
    FOREIGN KEY (account) REFERENCES user (account),
    FOREIGN KEY (number) REFERENCES book (number)
);

